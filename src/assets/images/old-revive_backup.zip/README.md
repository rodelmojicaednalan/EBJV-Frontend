Welcome to the Nodejs application of the Ticketing System
