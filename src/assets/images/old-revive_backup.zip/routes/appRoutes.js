const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const roleController = require('../controllers/roleController'); 
const {permission , can}= require('../middleware/permissionMiddleware');
const permissionController = require('../controllers/permissionController');
const userRoleController = require('../controllers/userRoleController');
const rolePermissionController = require('../controllers/rolePermissionController');
const ticketController = require('../controllers/ticketController');
const branchController = require('../controllers/branchController');
const ticketTypeController = require('../controllers/ticketTypeController');
const staffLogController = require('../controllers/staffLogController');
const userBranchesController = require('../controllers/userBranchController');

const authorize = require('../middleware/authorizationMiddleware'); 
router.use(authorize);

const permit = require('../middleware/permissionMiddleware');

// CRUD Routes for User
router.get('/users', userController.getUsers);
router.get('/user/:id', userController.getUserById);
router.get('/user', userController.getCurrentUser);
router.post('/addUser',  userController.addUser);
router.post('/login', userController.login);
router.post('/logout', userController.logout);
router.post('/refresh', userController.refresh);
router.put('/update-user/:id', userController.updateUser);
router.delete('/delete-user/:id', userController.deleteUser);
router.put('/update-profile', userController.updateProfile);

// CRUD Routes for Role
router.get('/roles', roleController.getRoles);
router.get('/role/:id', roleController.getRoleById);
router.post('/create-role', roleController.createRole);
router.put('/update-role/:id', roleController.updateRole);
router.delete('/delete-role/:id', roleController.deleteRole);

// CRUD Routes for Permissions
router.get('/permissions', permissionController.getPermissions);
router.get('/permission/:id', permissionController.getPermissionById);
router.post('/create-permission', permissionController.createPermission);
//router.put('/update-permission/:id', permissionController.updatePermission);
//router.delete('/delete-permission/:id', permissionController.deletePermission);

// CRUD Routes for Role Permissions
router.get('/rolePermissions', rolePermissionController.getRolePermission);
router.get('/rolePermission/:id', rolePermissionController.getRolePermissionById);
router.post('/create-rolePermission', rolePermissionController.createRolePermission);
router.put('/update-rolePermission/:id', rolePermissionController.updateRolePermission);
router.delete('/delete-rolePermission/:id', rolePermissionController.deleteRolePermission);

// CRUD Routes for User Roles
router.get('/userRoles', userRoleController.getUserRoles);
router.delete('/delete-userRole/:id', userRoleController.deleteUserRole);

// Routes for users_branch table
router.get('/users-branches', userBranchesController.getUsersByBranch);
router.post('/create-user-in-branch', userBranchesController.createUserinBranch);
router.delete('/delete-user-in-branch', userBranchesController.deleteUserByBranch);

// Branch Routes
router.get('/branches', branchController.getAllBranches);
router.get('/branch/:id', branchController.getBranchById);
router.post('/create-branch', branchController.createBranch);
router.put('/update-branch/:id', branchController.updateBranch);
router.delete('/delete-branch/:id', branchController.deleteBranch);

// Ticket Routes
router.get('/tickets', ticketController.getTickets);
router.get('/ticket/:id', ticketController.getTicketByCode);
router.post('/create-ticket',  ticketController.createTicket);
router.put('/update-ticket/:id', ticketController.updateTicket);
router.delete('/delete-ticket/:id', ticketController.deleteTicket);
router.post('/mass-delete-tickets', ticketController.massDeleteTickets);

// Ticket Type Routes
router.get('/ticketTypes', ticketTypeController.getTicketTypes);
router.get('/ticketType/:id', ticketTypeController.getTicketTypeById);
router.post('/create-ticketType', ticketTypeController.createTicketType);
router.put('/update-ticketType/:id', ticketTypeController.updateTicketType);
router.delete('/delete-ticketType/:id', ticketTypeController.deleteTicketType);

// Staff Log Route
router.get('/staffLogs', staffLogController.getAllStaffLogs);
router.delete('/delete-log/:id', staffLogController.deleteStaffLog);
router.post('/mass-delete-logs/', staffLogController.massDeleteLogs);

module.exports = router;

