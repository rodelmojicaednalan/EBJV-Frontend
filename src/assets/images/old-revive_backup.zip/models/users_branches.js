'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
    
  class UserBranches extends Model {
    static associate(models) {
        UserBranches.belongsTo(models.users, {
        foreignKey: 'user_id',
      });
      
      UserBranches.belongsTo(models.branches, {
        foreignKey: 'branch_id',
      });
    }
  }

  UserBranches.init({
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'users', 
        key: 'id'
      }
    },
   branch_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'branches', 
        key: 'id'
      }
    }
  }, {
    timestamps:true,
    sequelize,
    modelName: 'users_branches',
       indexes: [
      {
        unique: true,
        fields: ['user_id', 'branch_id']
      }
    ]
  });
  return UserBranches;
};