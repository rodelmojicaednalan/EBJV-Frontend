'use strict';
const {Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Branch extends Model {
    static associate(models) {
      Branch.belongsToMany(models.users, {
        through: models.users_branches,
        foreignKey: 'branch_id',
      });
    }
  }
  
  Branch.init({
    branch_name: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    branch_address: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    operating_hours: {
      type: DataTypes.JSONB,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'Closed',
      allowNull: false,
    }
  }, {
    timestamps:true,
    sequelize,
    modelName: 'branches',
        indexes: [
      {
        unique: true,
        fields: ['branch_name']
      }
    ]
  });
  return Branch;
};

