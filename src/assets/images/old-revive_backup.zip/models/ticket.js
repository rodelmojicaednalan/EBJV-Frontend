'use strict';
const {Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Ticket extends Model {
    static associate(models) {
      Ticket.belongsTo(models.branches,{
        foreignKey: 'branch_id',
      });

       Ticket.belongsTo(models.users,{
        foreignKey: 'user_id'
       });

       Ticket.belongsTo(models.ticketTypes,{
        foreignKey: 'ticket_type_id'
       });
    }
  }
  Ticket.init({
    ticket_type_id:{
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    data: {
      type: DataTypes.JSONB,
      allowNull: true,
    },
    user_id:{
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    branch_id:{
      type: DataTypes.INTEGER,
      allowNull: false,
    }
  }, {
    timestamps:true,
    sequelize,
    modelName: 'tickets',
  });
  return Ticket;
};

