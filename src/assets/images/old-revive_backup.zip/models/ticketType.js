'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class TicketType extends Model {
    static associate(models) {
      TicketType.hasMany(models.tickets, {
        foreignKey: 'ticket_type_id',
      });
    }
  }

  TicketType.init({
    ticket_type: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
  }, {
    timestamps:true,
    sequelize,
    modelName: 'ticketTypes',
  });

  return TicketType;
};
