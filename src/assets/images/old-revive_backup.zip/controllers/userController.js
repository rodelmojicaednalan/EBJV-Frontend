const {users, staff_logs, branches, roles, users_roles, permissions, users_branches} = require('../models');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { setTokens, clearTokens } = require('../utils/tokenUtils');
const JWT_SECRET = process.env.JWT_SECRET;
require('dotenv').config();

const getUsers = async (req, res) => {
  try {
    const user = await users.findAll({
      order: [['id', 'ASC']],
      include: [
        {
          model: roles,
          attributes: ['role_name']
        },
        {
          model: branches,
          through: { attributes: [] },
          attributes: ['id', 'branch_name']
        },
      ],
      attributes: ['id', 'first_name', 'last_name', 'sex', 'username', 'email']
    });
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getUserById = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const user = await users.findByPk(id, {
      include: [
        {
          model: branches,
          through: { attributes: [] }, 
          attributes: ['id', 'branch_name']
        },
        {
          model: roles,
          attributes: ['role_name']
        }
      ],
      attributes: ['id', 'first_name', 'last_name', 'sex', 'username', 'email', 'password']
    });
    if (user) {
      res.status(200).json(user);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const getCurrentUser = async (req, res) => {
  try {
    const userId = req.user.id; // Assuming the user ID is available in the request object

    // Fetch user with associated role and branch
    const user = await users.findByPk(userId, {
      include: [
        {
          model: branches,
          through: { attributes: [] }, 
          attributes: ['branch_name'] 
        },
        {
          model: roles,
          attributes: ['role_name', 'role_description'], 
        }
      ],
      attributes: ['id', 'first_name', 'last_name', 'sex', 'username', 'email']
    });

    if (user) {
      // Extract and format the role and permissions data
      const rolesWithPermissions = user.roles.map(role => ({
        role_name: role.role_name,
        role_description: role.role_description,
      }));

      // Prepare the response object
      const response = {
        id: user.id,
        first_name: user.first_name,
        last_name: user.last_name,
        sex: user.sex,
        username: user.username,
        email: user.email,
        branch: user.branches.map(branch =>branch.branch_name) || [],
        roles: rolesWithPermissions
      };

      res.status(200).json(response);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const addUser = async (req, res) => {
  const { first_name, last_name, sex, username, email, password, branch_ids, role_name} = req.body;
  try {
    const newUser = await users.create({first_name, last_name, sex, username, email, password, branch_ids });
   
    const role = await roles.findOne({where: {role_name}});
    if(!role){
      return res.status(400).json({error: 'Role Not Found'});
    }
    await users_roles.create({
      user_id: newUser.id,
      role_id: role.id
    });
    
     if (branch_ids && branch_ids.length > 0) {
      await Promise.all(branch_ids.map(branch_id =>
        users_branches.create({
          user_id: newUser.id,
          branch_id
        })
      ));
    }
    
    res.status(201).json({ message: 'User created successfully', user: newUser });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const login = async (req, res) => {
  const { username, password } = req.body;
  
  try {
    const user = await users.findOne({ where: { username } ,
      include: [
        {
          model: roles,
          as: 'roles', 
          include: {
            model: permissions,
            as: 'permissions', 
            through: { attributes: [] } 
          }
        },
      ] 
    
    });
    if (!user) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }   

    const accessToken = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '2h' });
    const refreshToken = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
    const roleName = user.roles.some(role => role.role_name === 'Admin') ? 'Admin' : 'Staff';

  
    setTokens(res, accessToken, refreshToken);
    res.cookie('role_name', roleName, { httpOnly: true, secure: true });

    
    await staff_logs.create({ user_id: user.id, action: 'login'});

    const roleAndpermission = user.roles.map(role => ({
      role_name: role.role_name,
      permission: role.permissions.map(permission => permission.permission_name)
    }));

    res.status(200).json({ 
      accessToken, 
      refreshToken,
      roleName,
      user: {
        first_name: user.first_name,
        last_name: user.last_name,
        username: user.username,
        password: user.password,
        email: user.email,
        roles: roleAndpermission 
      },
      message: 'Logged in successfully'});
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const logout = async (req, res) => {
  try{
    const user_id = req.user.id;

    clearTokens(res);

    await staff_logs.create({ user_id, action: 'logout'});
    res.status(200).json({message: 'Logged out successfully'});
  } catch(error){
    res.status(500).json({error: error.message});
  }
};

const refresh = async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) {
    return res.sendStatus(401);
  }
  try {
    jwt.verify(refreshToken, JWT_SECRET, (err, user) => {
      if (err) return res.sendStatus(403);
      const newAccessToken = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '2h' });
      setTokens(res, newAccessToken, refreshToken);
      res.json({ accessToken: newAccessToken });
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateUser = async (req, res) => {
  const id = parseInt(req.params.id);
  const { first_name, last_name, sex, username, email, password, role_name, branch_ids} = req.body;
  try {
    const user = await users.findByPk(id);

    if (user) {
      user.first_name = first_name;
      user.last_name = last_name;
      user.sex = sex;
      user.username = username;
      user.email = email;
      if (password) {
        user.password = password; 
      }
      await user.save();

      if (role_name) {
        const role = await roles.findOne({ where: { role_name } });
        if (role) {
          await users_roles.update(
            { role_id: role.id },
            { where: { user_id: user.id } }
          );
        } else {
          return res.status(404).json({ error: 'Role not found' });
        }
      }
      
      if (branch_ids) {
        await users_branches.destroy({ where: { user_id: user.id } }); 
        const branchAssignments = branch_ids.map(branch_id => ({
          user_id: user.id,
          branch_id
        }));
        await users_branches.bulkCreate(branchAssignments); 
      }

      res.status(200).json({message: 'User Updated Successfully'});
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteUser = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const deleted = await users.destroy({ where: { id } });
    if (deleted) {
      res.status(200).json({ message: `User deleted with ID: ${id}` });
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateProfile = async (req, res) => {
  const { username, email, oldPassword, newPassword } = req.body;

  try {
    const userId = req.user.id;
    const user = await users.findByPk(userId);

    // Ensure the user exists
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

     if (newPassword) {
      // Only check the old password if a new password is provided
      const validPassword = await bcrypt.compare(oldPassword, user.password);
      if (!validPassword) {
        return res.status(400).json({ message: 'Old password is incorrect.' });
      }

      // Update the password directly; the hook will hash it
      user.password = newPassword;
    }

    // Update username and email if provided
    if (username) user.username = username;
    if (email) user.email = email;

    await user.save();
    res.status(200).json({ message: 'Profile updated successfully.' });
  } catch (error) {
    console.error("Error updating profile:", error);
    res.status(500).json({ message: 'Server error. Please try again later.' });
  }
};

module.exports = {
  getUsers,
  getUserById,
  getCurrentUser,
  addUser,
  refresh,
  login,
  logout,
  updateUser,
  deleteUser,
  updateProfile
};