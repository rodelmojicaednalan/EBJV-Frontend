const {ticketTypes} = require('../models');

const createTicketType = async (req, res) => {
  const {ticket_type } = req.body;
  try {
    const newTicketType = await ticketTypes.create({ ticket_type });
    res.status(201).json({ message: `Ticket Type created with ID ${newTicketType.id}` });
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      res.status(400).json({ error: 'Ticket Type already exists.' });
    } else if (error.name === 'SequelizeForeignKeyConstraintError') {
      res.status(400).json({ error: 'Invalid data provided.' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
};

const getTicketTypes = async (req, res) => {
  try {
    const allTicketTypes = await ticketTypes.findAll({ order: [['id', 'ASC']] });
    res.status(200).json(allTicketTypes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getTicketTypeById = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const ticketType= await ticketTypes.findByPk(id);
    if (ticketType) {
      res.status(200).json(ticketType);
    } else {
      res.status(404).json({ error: 'Ticket Type not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateTicketType = async (req, res) => {
  const id = parseInt(req.params.id);
  const { ticket_type } = req.body;
  try {
    const [updated] = await ticketTypes.update({ ticket_type }, { where: { id } });
    if (updated) {
      const updatedTicketType = await ticketTypes.findOne({ where: { id } });
      res.status(200).json(updatedTicketType);
    } else {
      res.status(404).json({ error: 'Ticket Type not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteTicketType = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const deleted = await ticketTypes.destroy({ where: { id } });
    if (deleted) {
      res.status(200).json({ message: 'Ticket Type deleted successfully' });
    } else {
      res.status(404).json({ error: 'Ticket Type not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createTicketType,
  getTicketTypes,
  getTicketTypeById,
  updateTicketType,
  deleteTicketType,
};
