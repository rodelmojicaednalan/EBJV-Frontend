const {tickets, users, ticketTypes, branches, roles} = require('../models');
const path = require('path');
const fs = require('fs');

const ticketTemplateMap = {
  "HOT PRICE TAGS (with RRP + Save)": 1,
  "CATALOGUE SPECIALS PRICE TAGS": 2,
  "A4 BIG TICKET LANDSCAPE": 3,
  "HOT PRICE TAGS (without RRP + Save)": 4,
  "GREEN FRIDAY SALE TAGS": 5,
  "MUST TRY TAGS": 6,
  "NEW IN STORE TAGS": 7,
  "PERCENTAGE OFF TAGS": 8,
  "REVLON FRAGRANCE TAGS": 9,
  "GREEN FRIDAY SALE TAGS - PERCENTAGE OFF": 10,
  "FROSTBLAND FRAGRANCE TAGS": 11,
  "DB FRAGRANCE TAGS": 12,
  "COTY FRAGRANCE TAGS": 13,
  "CLEARANCE TAGS": 14,
  "A4 TICKET - PERCENTAGE OFF": 15,
  "A4 TICKET - NEW IN STORE": 16,
  "A4 TICKET - CLEARANCE": 17,
  "SUPER SAVINGS TICKET - I'M GREAT VALUE TAGS": 18,
  "COSMAX FRAGRANCE TAGS": 19,
  "VALUE PACK TICKETS -I'M CHEAPER THAN TAGS": 20,
  "DAVKA FRAGRANCE TAGS": 21,
  "BASIC PRICE TAGS": 22
};

const createTicket = async (req, res) => {
  const { ticket_type, data } = req.body;
  const { user } = req;

  try {
    // Fetch the user's branches through the join table
    const userWithBranches = await users.findByPk(user.id, {
      include: [{ model: branches }]
    });

    if (!userWithBranches.branches || userWithBranches.branches.length === 0) {
      return res.status(400).json({ error: 'User is not assigned to any branch.' });
    }

    // You can choose which branch to assign here, e.g., the first one
    const branch_id = userWithBranches.branches[0].id; // or any logic to choose the branch
    
    const ticket_type_id = ticketTemplateMap[ticket_type];

      if (!ticket_type_id) {
        return res.status(400).json({ error: 'Invalid ticket type.' });
      }
    
    const newTicket = await tickets.create({
      ticket_type_id,
      data,
      user_id: user.id,
      branch_id: branch_id,
    });

    res.status(201).json({ message: `Ticket created with ID ${newTicket.id}` });
  } catch (error) {
    if (error.name === 'SequelizeUniqueConstraintError') {
      res.status(400).json({ error: 'Ticket already exists.' });
    } else if (error.name === 'SequelizeForeignKeyConstraintError') {
      res.status(400).json({ error: 'Invalid data provided.' });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
};


const getTickets = async (req, res) => {
  try {
    const allTickets = await tickets.findAll({ order: 
    [['createdAt', 'ASC']],
    include: [
            {
          model: users,
          include: [
            {
              model: roles,
              attributes: ['role_name'], // Include the role name from roles
            },
          ],
          attributes: ['first_name', 'last_name'], // Include user attributes
        },
            {
                model:branches,
                attributes:['branch_name']
            },
            {
                model:ticketTypes,
                attributes:['ticket_type']
            },
            
        ]
       
    });
    res.status(200).json(allTickets);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getTicketByCode = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const ticket = await tickets.findByPk(id);
    if (ticket) {
      res.status(200).json(ticket);
    } else {
      res.status(404).json({ error: 'Ticket not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateTicket = async (req, res) => {
  const id = parseInt(req.params.id);
  const {ticket_type_id, data } = req.body;
  try {
    const [updated] = await tickets.update({ticket_type_id, data }, { where: { id } });
    if (updated) {
      const updatedTicket = await tickets.findOne({ where: { id } });
      res.status(200).json(updatedTicket);
    } else {
      res.status(404).json({ error: 'Ticket not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const deleteTicket = async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    const deleted = await tickets.destroy({ where: { id } });
    if (deleted) {
      res.status(200).json({ message: 'Ticket deleted successfully' });
    } else {
      res.status(404).json({ error: 'Ticket not found' });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


const massDeleteTickets = async (req,res) => {
    const { ids } = req.body;
    try{
      await tickets.destroy({ where: { id: ids } });
    res.status(200).send({ message: 'Selected tickets deleted successfully' });
  } catch (error) {
    res.status(500).send({ error: 'Failed to delete selected tickets' });
  }
  };
  
module.exports = {
  createTicket,
  getTickets,
  getTicketByCode,
  updateTicket,
  deleteTicket,
  massDeleteTickets
};
